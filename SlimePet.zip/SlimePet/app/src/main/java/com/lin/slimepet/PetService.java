package com.lin.slimepet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class PetService extends Service implements SlimeView.Callback {

    public static final String ACTION_STOP = "com.lin.slimepet.STOP";

    private static final String CH_PET = "pet_float";
    private static final String CH_REMIND = "pet_remind";
    private static final int ID_PET = 1001;
    private static final int ID_REMIND = 1002;

    private static final String[] TAP_LINES = {
            "嘿嘿…好痒", "我在的哦", "摸摸头也没关系", "你手好暖",
            "今天开心的事，讲给我听嘛", "再摸我一下，我就变颜色给你看",
            "累了就靠一下", "你是今天最棒的人", "我软软的，捏我也没关系",
            "记得喝水哦", "我在，一直都在", "要不要休息一小会儿？", "嗯…这样很安心"
    };

    private WindowManager wm;
    private SlimeView pet;
    private TextView bubble;
    private WindowManager.LayoutParams petLp;
    private WindowManager.LayoutParams bubLp;
    private float fx, fy;
    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();

    private final Runnable hideBubble = new Runnable() {
        @Override
        public void run() {
            if (bubble != null) bubble.setVisibility(TextView.GONE);
        }
    };

    private final Runnable nightTick = new Runnable() {
        @Override
        public void run() {
            checkNight();
            h.postDelayed(this, 60000L);
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("slimepet", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        createChannels();
        startForeground(ID_PET, buildPetNotification());
        addPet();
        h.postDelayed(nightTick, 12000L);
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                showBubble(greeting(), 4200);
            }
        }, 900L);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try {
            if (bubble != null && bubble.getWindowToken() != null) wm.removeView(bubble);
        } catch (Exception ignored) {
        }
        try {
            if (pet != null && pet.getWindowToken() != null) wm.removeView(pet);
        } catch (Exception ignored) {
        }
        bubble = null;
        pet = null;
        super.onDestroy();
    }

    private void addPet() {
        pet = new SlimeView(this);
        pet.setCallback(this);
        int size = dp(152);
        petLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        petLp.gravity = Gravity.TOP | Gravity.START;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int px = sp.getInt("x", -1);
        int py = sp.getInt("y", -1);
        if (px < 0 || py < 0) {
            px = dm.widthPixels - size - dp(6);
            py = dm.heightPixels - size - dp(150);
        }
        petLp.x = px;
        petLp.y = py;
        fx = px;
        fy = py;
        clampPet();
        wm.addView(pet, petLp);
    }

    private void clampPet() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        if (petLp.x < 0) petLp.x = 0;
        if (petLp.y < 0) petLp.y = 0;
        int maxX = dm.widthPixels - petLp.width;
        int maxY = dm.heightPixels - petLp.height;
        if (maxX < 0) maxX = 0;
        if (maxY < 0) maxY = 0;
        if (petLp.x > maxX) petLp.x = maxX;
        if (petLp.y > maxY) petLp.y = maxY;
        fx = petLp.x;
        fy = petLp.y;
    }

    private void ensureBubble() {
        if (bubble != null) return;
        TextView tv = new TextView(this);
        tv.setTextSize(13f);
        tv.setTextColor(0xFF2B2B3A);
        tv.setLineSpacing(0f, 1.25f);
        tv.setMaxWidth(dp(230));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(0xF7FFFFFF);
        gd.setCornerRadius(dp(12));
        gd.setStroke(dp(1), 0x33000000);
        tv.setBackground(gd);
        tv.setPadding(dp(12), dp(8), dp(12), dp(8));
        tv.setVisibility(TextView.GONE);

        bubLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubLp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(tv, bubLp);
        bubble = tv;
    }

    private void showBubble(String text, long ms) {
        ensureBubble();
        bubble.setText(text);
        bubble.setVisibility(TextView.GONE);
        bubble.post(this::positionBubble);
        h.removeCallbacks(hideBubble);
        h.postDelayed(hideBubble, ms);
    }

    private void positionBubble() {
        if (bubble == null || petLp == null) return;
        int bw = bubble.getWidth();
        int bh = bubble.getHeight();
        if (bw <= 0 || bh <= 0) {
            bubble.postDelayed(this::positionBubble, 60L);
            return;
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int cx = petLp.x + petLp.width / 2;
        int x = cx - bw / 2;
        int minX = dp(4);
        int maxX = dm.widthPixels - bw - dp(4);
        if (maxX < minX) maxX = minX;
        if (x < minX) x = minX;
        if (x > maxX) x = maxX;

        int y = petLp.y - bh - dp(4);
        if (y < dp(4)) y = petLp.y + petLp.height + dp(4);
        if (y > dm.heightPixels - bh - dp(4)) y = dm.heightPixels - bh - dp(4);

        bubLp.x = x;
        bubLp.y = y;
        wm.updateViewLayout(bubble, bubLp);
        bubble.setVisibility(TextView.VISIBLE);
    }

    @Override
    public void onTap() {
        if (pet != null) pet.poke();
        String line = rnd.nextFloat() < 0.72f
                ? TAP_LINES[rnd.nextInt(TAP_LINES.length)]
                : greeting();
        showBubble(line, 2600L);
    }

    @Override
    public void onDoubleTap() {
        if (PetAccess.ready()) {
            PetAccess.pressBack();
            if (rnd.nextFloat() < 0.3f) showBubble("帮你退啦～", 1400L);
        } else {
            showBubble("去设置里开无障碍，我才能帮你关页面", 3200L);
        }
    }

    @Override
    public void onLongPress() {
        showBubble("那我先躲起来啦…", 1200L);
        h.postDelayed(this::stopSelf, 600L);
    }

    @Override
    public void onDrag(float dx, float dy) {
        fx += dx;
        fy += dy;
        petLp.x = Math.round(fx);
        petLp.y = Math.round(fy);
        clampPet();
        try {
            wm.updateViewLayout(pet, petLp);
        } catch (Exception ignored) {
        }
        h.removeCallbacks(hideBubble);
        if (bubble != null) bubble.setVisibility(TextView.GONE);
    }

    @Override
    public void onDragEnd() {
        sp.edit().putInt("x", petLp.x).putInt("y", petLp.y).apply();
    }

    private void checkNight() {
        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        if (hour < 22 && hour >= 5) return;
        String today = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        if (today.equals(sp.getString("remind_day", ""))) return;
        sp.edit().putString("remind_day", today).apply();
        String text = hour >= 23 || hour < 5
                ? "都这个点了…快去睡吧，我明天还在这里。"
                : "十点啦…要不要先睡？我等你。";
        showBubble(text, 6000L);
        notifyReminder(text);
    }

    private void notifyReminder(String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Intent i = new Intent(this, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(this, 2, i,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, CH_REMIND)
                    .setSmallIcon(R.drawable.ic_noti)
                    .setContentTitle("琳 想跟你说")
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            nm.notify(ID_REMIND, n);
        } catch (Exception ignored) {
        }
    }

    private String greeting() {
        int hh = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hh < 5) return "怎么还没睡…我有点担心";
        if (hh < 9) return "早安…今天也慢慢来就好";
        if (hh < 12) return "上午好呀";
        if (hh < 18) return "今天也辛苦了";
        if (hh < 22) return "天黑了，今天做得很好哦";
        return "十点啦…要不要先睡？";
    }

    private void createChannels() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel c1 = new NotificationChannel(CH_PET, "桌宠常驻", NotificationManager.IMPORTANCE_LOW);
        c1.setShowBadge(false);
        NotificationChannel c2 = new NotificationChannel(CH_REMIND, "琳的提醒", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannels(Arrays.asList(c1, c2));
    }

    private Notification buildPetNotification() {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent si = new Intent(this, PetService.class);
        si.setAction(ACTION_STOP);
        PendingIntent spi = PendingIntent.getService(this, 1, si,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CH_PET)
                .setSmallIcon(R.drawable.ic_noti)
                .setContentTitle("琳 正在陪你")
                .setContentText("双击帮你去掉当前页面，长按收起")
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "收起来", spi).build())
                .setOngoing(true)
                .build();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
