package com.lin.slimepet;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final int REQ_NOTI = 21;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(56), dp(24), dp(24));
        root.setBackgroundColor(0xFFFAF7F2);

        TextView title = new TextView(this);
        title.setText("琳");
        title.setTextSize(34f);
        title.setTextColor(0xFF2B2B3A);
        title.setGravity(Gravity.CENTER);

        TextView sub = new TextView(this);
        sub.setText("会飘在所有 App 上方的果冻史莱姆\n单击摸摸 / 双击关掉当前页面 / 长按收起");
        sub.setTextSize(13.5f);
        sub.setTextColor(0xFF7A7A88);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(0f, 1.45f);
        sub.setPadding(0, dp(14), 0, dp(28));

        Button go = new Button(this);
        go.setText("让琳出来");
        go.setOnClickListener(v -> startPet());

        Button hide = new Button(this);
        hide.setText("让琳收起来");
        hide.setOnClickListener(v -> {
            stopService(new Intent(this, PetService.class));
            status.setText("琳回去睡觉了");
        });

        Button acc = new Button(this);
        acc.setText("开启「双击关页面」能力");
        acc.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivity(i);
                status.setText("在无障碍列表里找到「琳」，打开开关，然后回到这里");
            } catch (Exception e) {
                status.setText("打不开无障碍设置，请手动进入：设置 → 辅助功能 → 无障碍");
            }
        });

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        acc.setLayoutParams(lp);

        status = new TextView(this);
        status.setTextSize(13f);
        status.setTextColor(0xFF9A9AA8);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(18), 0, 0);

        root.addView(title);
        root.addView(sub);
        root.addView(go);
        root.addView(hide);
        root.addView(acc);
        root.addView(status);
        setContentView(root);

        askNotification();
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        if (status == null) return;
        boolean overlay = Settings.canDrawOverlays(this);
        boolean acc = PetAccess.ready();
        StringBuilder sb = new StringBuilder();
        sb.append(overlay ? "✅ 悬浮窗权限已开" : "❌ 悬浮窗权限未开（必须先开）");
        sb.append("\n");
        sb.append(acc ? "✅ 双击关页面已可用" : "○ 双击关页面未开启（可选）");
        status.setText(sb.toString());
    }

    private void startPet() {
        if (!Settings.canDrawOverlays(this)) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
            }
            status.setText("请先打开「允许显示在其他应用上层」，再回来点一次");
            return;
        }
        Intent s = new Intent(this, PetService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(s);
        } else {
            startService(s);
        }
        status.setText("琳出来啦～拖着能换位置，双击帮你退出当前页面");
    }

    private void askNotification() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTI);
        }
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
